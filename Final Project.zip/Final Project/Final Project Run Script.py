# -*- coding: utf-8 -*-
#Author:  Nathaniel Kickbush
#Date written: 07/17/23
#Assignment:   final Project
#Short Desc:   character attribute generator

import sys, math, random

from PyQt5.QtWidgets import QApplication, QDialog, QMainWindow

from easyCharacterSheet import Ui_easyCharacterSheet

from printableSheet import Ui_printableSheet

class PrintableSheet(QDialog, Ui_printableSheet):
    
    #creating the initiation of the ui for qdialog printablesheet
    
    def __init__(self, *args, obj=None, **kwargs):
        
        super(PrintableSheet, self).__init__(*args,**kwargs)
        
        self.setupUi(self)
            
    def createPrintableSheet(self, strength, dex, con, intell, wis, cha, playerName, characterName):
                
        #setting the value box to the corresponding int variable
            
        self.printStrengthValue.setValue(strength)
        self.printDexValue.setValue(dex)
        self.printConValue.setValue(con)
        self.printIntValue.setValue(intell)
        self.printWisValue.setValue(wis)
        self.printCharValue.setValue(cha)
                
                
        #setting the modifier box using the standard formula for finding the modifier from the corresponding value
                
        self.printStrengthModifier.setValue(math.floor((strength - 10) / 2))
        self.printDexModifier.setValue(math.floor((dex - 10) / 2))
        self.printConModifier.setValue(math.floor((con - 10) / 2))
        self.printIntModifier.setValue(math.floor((intell - 10) / 2))
        self.printWisModifier.setValue(math.floor((wis - 10) / 2))
        self.printCharModifier.setValue(math.floor((cha - 10) / 2))
        
        self.printPlayerNameLabel.setText(playerName)
        self.printCharacterNameLabel.setText(characterName)
       
        #opening printableSheet
                
        self.exec()
            
class Window(QMainWindow, Ui_easyCharacterSheet, Ui_printableSheet):
    
    #creating the initiation of the ui for qdialog mainwindow "Window"    
    
    def __init__(self, *args, obj=None, **kwargs):
        
        super(Window, self).__init__(*args,**kwargs)
        
        self.setupUi(self)
            
        self.dialogPrint = PrintableSheet(self)
        
    #button click apply to start applyMain
        
        self.mainApplyButton.clicked.connect(self.applyMain)
        
    #button click random to start randomMain
    
        self.mainRandomButton.clicked.connect(self.randomMain)
        
    #button click quit to exit the program
        
        self.mainQuitButton.clicked.connect(self.finished)
            
    def openPrintableSheet(self):
            
    #opening printable sheet dialog
            
        self.dialogPrint.exec()
        
    def applyMain(self):
            
    #setting the values obtained from mainwindow qspinboxes to variables
        
        self.strength = self.strengthValue.value()
        self.dexterity = self.dexterityValue.value()
        self.constitution = self.constitutionValue.value()
        self.intelligence = self.intelligenceValue.value()
        self.wisdom = self.wisdomValue.value()
        self.charisma = self.charismaValue.value()
        
    #assigns the player name and character name to variables
    
        self.playerName = self.mainPlayerNameLine.text()
        self.characterName =self.mainCharacterNameLine.text()
        
        #sending variables to class PrintableSheet
        
        self.dialogPrint.createPrintableSheet(self.strength, self.dexterity, self.constitution, self.intelligence, self.wisdom, self.charisma, self.playerName, self.characterName)
        
    def randomMain(self):

    #create a list with the following values of 15,14,13,12,10,8 (standard values for starting characters)
    
        self.randomNumbers = [15,14,13,12,10,8]
        
    #shuffles the list to make a random list of predetermined values then removes the values one at a time with pop
           
        random.shuffle(self.randomNumbers)
    
    #assigns each variable a value from pop
    
        self.strength = self.randomNumbers.pop()            
        self.dexterity = self.randomNumbers.pop()     
        self.constitution = self.randomNumbers.pop()
        self.intelligence = self.randomNumbers.pop()
        self.wisdom = self.randomNumbers.pop()
        self.charisma = self.randomNumbers.pop()
        
    #assigns the player name and character name to variables
    
        self.playerName = self.mainPlayerNameLine.text()
        self.characterName = self.mainCharacterNameLine.text()
          
    #sending variables to class PrintableSheet
            
        self.dialogPrint.createPrintableSheet(self.strength, self.dexterity, self.constitution, self.intelligence, self.wisdom, self.charisma, self.playerName, self.characterName)
            
    def finished(self):
        
    #exits the application   
        
        sys.exit()
            
app = QApplication(sys.argv)
window = Window()
window.show()
app.exec()